<?php

namespace Tests\Unit;

use App\Domain\Deployments\DeploymentStateMachine;
use App\Domain\Deployments\DeploymentStatus;
use App\Domain\Deployments\GitHubWebhookVerifier;
use App\Domain\Deployments\HealthCheckPolicy;
use App\Domain\Deployments\ImmutableImageTag;
use App\Domain\Deployments\ReleaseColor;
use App\Domain\Deployments\ReleasePlanner;
use App\Domain\Deployments\SecretRedactor;
use DomainException;
use PHPUnit\Framework\TestCase;

final class DeploymentDomainTest extends TestCase
{
    public function test_health_gate_and_release_planner_never_promote_unhealthy_candidate(): void
    {
        $health = new HealthCheckPolicy('/health', 200, 3000, 10, 'ready');
        self::assertTrue($health->passes(200, '{"status":"ready"}'));
        self::assertFalse($health->passes(500, 'ready'));
        self::assertFalse((new ReleasePlanner())->mayPromote(false, true));
        self::assertSame(ReleaseColor::Green, (new ReleasePlanner())->candidate(ReleaseColor::Blue));
    }

    public function test_state_machine_rejects_skipping_health_check(): void
    {
        $this->expectException(DomainException::class);
        (new DeploymentStateMachine())->assert(DeploymentStatus::Building, DeploymentStatus::Succeeded);
    }

    public function test_webhook_secret_redaction_and_immutable_image_identity(): void
    {
        $payload = '{"after":"abc"}'; $secret = 'top-secret';
        $signature = 'sha256='.hash_hmac('sha256', $payload, $secret);
        self::assertTrue((new GitHubWebhookVerifier())->verify($payload, $signature, $secret));
        self::assertSame('token=[REDACTED]', (new SecretRedactor())->redact('token=top-secret', [$secret]));
        self::assertStringContainsString(':aaaaaaaaaaaa-build-1', (new ImmutableImageTag())->forCommit('registry.test','Project',str_repeat('a',40),'build-1'));
    }
}
