<?php

namespace Tests\Feature;

use App\Jobs\RunDeployment;
use App\Models\Environment;
use App\Models\Project;
use App\Models\WebhookDelivery;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Queue;
use Tests\Concerns\CreatesTenant;
use Tests\TestCase;

final class GitHubWebhookTest extends TestCase
{
    use RefreshDatabase, CreatesTenant;

    protected function setUp(): void
    {
        parent::setUp();
        config(['services.github.webhook_secret' => 'github-webhook-secret']);
    }

    public function test_verified_push_is_deduplicated_and_queues_exact_commit_once(): void
    {
        Queue::fake();
        [, $organization] = $this->tenant('github');
        $project = Project::create(['organization_id'=>$organization->id,'name'=>'App','slug'=>'app','repository_identifier'=>'owner/app','default_branch'=>'main','auto_deploy_enabled'=>true]);
        Environment::create(['project_id'=>$project->id,'name'=>'production','deployment_strategy'=>'blue_green','health_check_config'=>['path'=>'/health']]);
        $payload = json_encode(['ref'=>'refs/heads/main','after'=>str_repeat('b',40),'repository'=>['full_name'=>'owner/app'],'head_commit'=>['message'=>'ship it']], JSON_THROW_ON_ERROR);
        $signature = 'sha256='.hash_hmac('sha256',$payload,'github-webhook-secret');
        $headers = ['X-GitHub-Delivery'=>'delivery-1','X-GitHub-Event'=>'push','X-Hub-Signature-256'=>$signature,'Content-Type'=>'application/json'];

        $this->call('POST','/api/webhooks/github',[],[],[],$this->transformHeadersToServerVars($headers),$payload)->assertStatus(202);
        $this->call('POST','/api/webhooks/github',[],[],[],$this->transformHeadersToServerVars($headers),$payload)->assertStatus(202)->assertSee('duplicate');
        self::assertSame(1, WebhookDelivery::where('provider_delivery_id','delivery-1')->count());
        Queue::assertPushed(RunDeployment::class, 1);
    }

    public function test_invalid_signature_creates_rejected_delivery_and_never_deploys(): void
    {
        Queue::fake();
        $this->withHeaders(['X-GitHub-Delivery'=>'bad-1','X-GitHub-Event'=>'push','X-Hub-Signature-256'=>'sha256='.str_repeat('0',64)])
            ->post('/api/webhooks/github', [], ['CONTENT_TYPE'=>'application/json'])
            ->assertUnauthorized();
        self::assertSame('rejected', WebhookDelivery::where('provider_delivery_id','bad-1')->value('status'));
        Queue::assertNothingPushed();
    }
}
