<?php

namespace Tests\Feature;

use App\Jobs\RunDeployment;
use App\Models\Environment;
use App\Models\EnvironmentVariable;
use App\Models\Project;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Queue;
use Tests\Concerns\CreatesTenant;
use Tests\TestCase;

final class ControlPlaneSecurityTest extends TestCase
{
    use RefreshDatabase, CreatesTenant;

    public function test_project_and_environment_are_tenant_scoped(): void
    {
        [$user] = $this->tenant('owner'); [, $other] = $this->tenant('other');
        $project = Project::create(['organization_id'=>$other->id,'name'=>'Private','slug'=>'private','repository_identifier'=>'owner/private','default_branch'=>'main','auto_deploy_enabled'=>true]);
        $environment = Environment::create(['project_id'=>$project->id,'name'=>'production','deployment_strategy'=>'blue_green','health_check_config'=>['path'=>'/health']]);
        $this->actingAsTenant($user);
        $this->getJson('/api/environments/'.$environment->id)->assertForbidden();
    }

    public function test_environment_secret_is_encrypted_at_rest_and_never_returned(): void
    {
        [$user, $organization] = $this->tenant('secret'); $this->actingAsTenant($user);
        $project = Project::create(['organization_id'=>$organization->id,'name'=>'App','slug'=>'app','repository_identifier'=>'owner/app','default_branch'=>'main','auto_deploy_enabled'=>true]);
        $environment = Environment::create(['project_id'=>$project->id,'name'=>'production','deployment_strategy'=>'blue_green','health_check_config'=>['path'=>'/health']]);

        $response = $this->putJson("/api/environments/{$environment->id}/variables", [
            'key'=>'DATABASE_PASSWORD','value'=>'super-secret-value','scope'=>'runtime','is_secret'=>true,
        ])->assertOk()->assertJsonMissing(['value'=>'super-secret-value']);
        self::assertSame('••••••••', $response->json('value_masked'));

        $row = \DB::table('environment_variables')->where('id', $response->json('id'))->first();
        self::assertNotSame('super-secret-value', $row->encrypted_value);
        self::assertSame('super-secret-value', EnvironmentVariable::findOrFail($response->json('id'))->encrypted_value);
    }

    public function test_exact_sha_manual_deployment_is_queued_and_short_sha_is_rejected(): void
    {
        Queue::fake();
        [$user, $organization] = $this->tenant('deploy'); $this->actingAsTenant($user);
        $project = Project::create(['organization_id'=>$organization->id,'name'=>'App','slug'=>'app','repository_identifier'=>'owner/app','default_branch'=>'main','auto_deploy_enabled'=>true]);
        $environment = Environment::create(['project_id'=>$project->id,'name'=>'production','deployment_strategy'=>'blue_green','health_check_config'=>['path'=>'/health']]);

        $this->postJson("/api/environments/{$environment->id}/deployments", ['commit_sha'=>'abc123'])->assertUnprocessable();
        $created = $this->postJson("/api/environments/{$environment->id}/deployments", ['commit_sha'=>str_repeat('a',40),'branch'=>'main'])->assertStatus(202);
        self::assertSame(str_repeat('a',40), $created->json('commit_sha'));
        Queue::assertPushed(RunDeployment::class, 1);
    }
}
